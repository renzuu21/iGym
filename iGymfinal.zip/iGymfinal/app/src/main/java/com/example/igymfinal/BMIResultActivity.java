package com.example.igymfinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BMIResultActivity extends AppCompatActivity {

    private TextView textViewDetails, textViewBMI;
    private Button buttonBackToLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_result);

        textViewDetails = findViewById(R.id.textViewDetails);
        buttonBackToLogin = findViewById(R.id.buttonBackToLogin);

        // Retrieve data from Intent
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        int age = intent.getIntExtra("age", 0);
        String gender = intent.getStringExtra("gender");
        int height;
        height = intent.getIntExtra("height", 0);
        int weight;
        weight = intent.getIntExtra("weight", 0);
        float bmi = intent.getFloatExtra("bmi", 0);

        // Display user details and BMI
        String details = String.format("Name: %s\nAge: %d\nGender: %s\nBMI: %.2f\n%s", name, age, gender, bmi, getBodyType(bmi));
        textViewDetails.setText(details);


        // Set up button to go back to login
        buttonBackToLogin.setOnClickListener(v -> {
            Intent loginIntent = new Intent(BMIResultActivity.this, LoginActivity.class);
            startActivity(loginIntent);
        });
    }

    private String getBodyType(float bmi) {
        if (bmi < 18.5) {
            return "Body Type: Ectomorph";
        } else if (bmi < 24.9) {
            return "Body Type: Mesomorph";
        } else {
            return "Body Type: Endomorph";
        }
    }
}



